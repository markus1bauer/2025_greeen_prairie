#Rscript for: Zirbel, C.R., Bassett, T., Grman, E. and Brudvig, L.A. (2017)
#Plant functional traits and environmental conditions shape community assembly and ecosystem functioning during restoration
#Journal of Applied Ecology
#Dryad DOI: http://dx.doi.org/10.5061/dryad.9tp36
#Created by: Chad Zirbel
#R v. 3.3.0
#1/19/2017

#####Let's get started#####
#Clear R's global environment
rm(list=ls(all=TRUE))

#load required libraries
library(reshape2)
library(lavaan)
library(ggplot2)
library(Hmisc)
library(psych)
library(car)

##Load data
#The following code will pull the data files directly from Dryad
#Environmental data
site_data<-read.csv("http://www.datadryad.org/mn/object/doi:10.5061/dryad.2175q/3/bitstream")

#Species composition
species_abund<-read.csv("http://www.datadryad.org/mn/object/doi:10.5061/dryad.2175q/2/bitstream")

#Functional traits
trait_con<-read.csv("http://www.datadryad.org/mn/object/doi:10.5061/dryad.2175q/4/bitstream")
trait_lit<-read.csv("http://www.datadryad.org/mn/object/doi:10.5061/dryad.2175q/5/bitstream")

#Ecosystem functions
functions.byplot<-read.csv("http://www.datadryad.org/mn/object/doi:10.5061/dryad.2175q/1/bitstream")

#####Environmental data#####
#site age
site_data$age.2013<-2013-site_data$year

#Fire return interval
fire.return.2013<-site_data$no.burns/(site_data$age.2013)
site_data$fire.return<-fire.return.2013

#Soil PCA
soildata<-site_data
soil<-soildata[8:15]
pca.soil<-prcomp(soil, center=TRUE, scale=TRUE)#scale=TRUE, different scales across variables 
soilPC1<-pca.soil$x[,1]#56% variance; high values=sandy sites with low WHC (P loads high)

#invert the soil PCA axis (increasing WHC) and add to the data frame
site_data$soilPC1<-1*soilPC1

#landscape PCA
land <- site_data[3:7]
pca.land<-prcomp(land, center=TRUE, scale=FALSE)
landPC1<-pca.land$x[,1]#59% of variance; high values = high forest/grass, low ag

site_data$landscape<-landPC1

#create a binary land use variable
site_data$land.use.binary<-site_data$land.use
levels(site_data$land.use.binary)<-c("0", "0", "1") #0 is untilled, 1 is tilled
site_data$land.use.binary=as.numeric(levels(site_data$land.use.binary)[site_data$land.use.binary])

#cut data.frame to relevant variables
site_data<-site_data[c(1,18:22)]

####Species composition####
#sum species covers within sites and divide by number of plots (10)
#drop identifying columns (rownames now correspond to site.id)
species_abund_ag<-aggregate(species_abund[-c(1,2)],by=list(species_abund$site.id),sum)/10
species_abund_ag<-species_abund_ag[-1]

#####Functional traits####
#add pollination mode trait
trait_full<-merge(trait_lit,trait_con,by="species",all.x=T)
trait_full$flowers<-ifelse(trait_full$flowers=="Y",1,0)#change to binary

#Calculate mean trait values
trait_full<-cbind(trait_full[1],trait_full[8:11])
trait.melt<-melt(trait_full, id="species",na.rm=T)
trait.melt$value<-as.numeric(trait.melt$value)
trait_data=dcast(trait.melt, species~variable,mean,drop=F)#make it a matrix

#Add rownames, make sure species are in the correct order, and remove non-trait data
rownames(trait_data)<-trait_data$species
trait_data<-trait_data[order(row.names(trait_data)),]
trait_data<- trait_data[-1]

#Community Weighted means
output = matrix(NA, nrow=29, ncol =4); 
for(i in 1:4)
{ for(j in 1:29)
{ output[j,i] =weighted.mean(trait_data[,i], species_abund_ag[j,],na.rm=T)    
}}
colnames(output)=colnames(trait_data)
colnames(output)<-c("cwm.fr","cwm.height","cwm.sla","cwm.sm")
site_data<-cbind(site_data,output)

#Ecosystem functions####
#Average functions across plots within each site
#Find average floral cover across the three sampling months
melt.functions=melt(functions.byplot, id=c("site.id", "plot"))
functions=dcast(melt.functions, site.id~variable, mean, na.rm=TRUE)
functions$floral.cover=(functions$floral.cover.june + functions$floral.cover.july + functions$floral.cover.sept)/3
functions$floral.SR=(functions$floral.plotSR.june + functions$floral.plotSR.july + functions$floral.plotSR.sept)/3

#cut to functions of interest and add to data.frame
functions_final=cbind(functions[,1:3],functions[5],functions[10:11],functions[21])
site_data<-merge(site_data,functions_final,by="site.id")
site_data$biomass.kg<-site_data$biomass/1000 #make the variance a little more reasonable

#logit transform floral cover
min(site_data$floral.cover[site_data$floral.cover!=0])#minimum non-zero values to be added before transformation
site_data$fc.logit<-logit(site_data$floral.cover,adjust=.0646666)

#remove site.id var (rownames are site.ids)
site_data<-site_data[-1]

#check for deviation from multivariate normal
mardia(site_data$fc.logit,na.rm=T) #significan kurtosis. Use Satorra.Bentler adj Chi^2 in SEM
mardia(site_data$biomass.kg,na.rm=T)
mardia(site_data$roots.per.g.soil,na.rm=T)
mardia(site_data$mass.loss,na.rm=T)
mardia(site_data$aug.worms.gone,na.rm=T)
mardia(site_data$total.seeds.removed,na.rm=T)

####Structural equation models####
#model results may differ from those reported in the paper due to missing Kew seed mass data

model.floral.cover='cwm.fr~1
cwm.sla~fire.return+land.use.binary+age.2013+soilPC1 
cwm.height~soilPC1+land.use.binary+age.2013
cwm.sm~land.use.binary+age.2013
fc.logit~cwm.fr+cwm.sla+fire.return+soilPC1
cwm.height~~cwm.fr
cwm.height~~cwm.sla
cwm.height~~cwm.sm
cwm.sla~~cwm.fr
cwm.sla~~cwm.sm
cwm.sm~~cwm.fr
cwm.sm~~0*fc.logit
cwm.height~~0*fc.logit'
sem.model.floral.cover=sem(model.floral.cover, data=site_data,test="Satorra.Bentler")
summary(sem.model.floral.cover,standardized=T)
modificationIndices(sem.model.floral.cover,power=T)

#biomass
model.biomass='cwm.sla~fire.return+land.use.binary+age.2013+soilPC1 
cwm.height~soilPC1+land.use.binary+age.2013
cwm.sm~land.use.binary+age.2013
biomass.kg~cwm.height+fire.return+soilPC1+age.2013
cwm.height~~cwm.sla
cwm.height~~cwm.sm
cwm.sla~~cwm.sm
cwm.sla~~0*biomass.kg
cwm.sm~~0*biomass.kg'
sem.model.biomass=sem(model.biomass, data=site_data)
summary(sem.model.biomass,standardized=T)
modificationIndices(sem.model.biomass)

#decomposition
model.decomp='cwm.sla~fire.return+land.use.binary+age.2013+soilPC1 
cwm.height~soilPC1+land.use.binary+age.2013
cwm.sm~land.use.binary+age.2013
mass.loss~cwm.height+fire.return+soilPC1+age.2013
cwm.height~~cwm.sla
cwm.height~~cwm.sm
cwm.sla~~cwm.sm
cwm.sla~~0*mass.loss
cwm.sm~~0*mass.loss'
sem.model.decomp=sem(model.decomp, data=site_data)
summary(sem.model.decomp,standardized=T)
modificationIndices(sem.model.decomp)

#belowground biomass
model.below='cwm.sla~fire.return+land.use.binary+age.2013+soilPC1 
cwm.height~soilPC1+land.use.binary+age.2013
cwm.sm~land.use.binary+age.2013
roots.per.g.soil~cwm.sm+cwm.height+cwm.sla+soilPC1+age.2013
cwm.height~~cwm.sla
cwm.height~~cwm.sm
cwm.sla~~cwm.sm'
sem.model.below=sem(model.below, data=site_data)
summary(sem.model.below,standardized=T)
modificationIndices(sem.model.below)

#arthropod predation
model.arthro.pred='cwm.sla~fire.return+land.use.binary+age.2013+soilPC1 
cwm.height~soilPC1+land.use.binary+age.2013
cwm.sm~land.use.binary+age.2013
aug.worms.gone~cwm.height+fire.return+age.2013+landscape
cwm.height~~cwm.sla
cwm.height~~cwm.sm
cwm.sla~~cwm.sm
cwm.sm~~0*aug.worms.gone
cwm.sla~~0*aug.worms.gone'
sem.model.arthro.pred=sem(model.arthro.pred, data=site_data)
summary(sem.model.arthro.pred,standardized=T)
modificationIndices(sem.model.arthro.pred)

#seed predation
model.seed.pred='cwm.sla~fire.return+land.use.binary+age.2013+soilPC1 
cwm.height~soilPC1+land.use.binary+age.2013
cwm.sm~land.use.binary+age.2013
total.seeds.removed~cwm.height+fire.return+age.2013+landscape
cwm.height~~cwm.sla
cwm.height~~cwm.sm
cwm.sla~~cwm.sm
cwm.sm~~0*total.seeds.removed
cwm.sla~~0*total.seeds.removed'
sem.model.seed.pred=sem(model.seed.pred, data=site_data)
summary(sem.model.seed.pred,standardized=T)
modificationIndices(sem.model.seed.pred)

####Figures####
#Figure 3 reports the total standardized effects within each of the above models which can be found using summary()

#test significance of trait correlations for CWMs
rcorr(as.matrix(output))

#plot the correlations between cwm trait values (fig. 4)
c1<-ggplot(data=as.data.frame(output),aes(x=cwm.height,y=cwm.sla))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "CWM vegetative height (m)", y =bquote('CWM SLA ('*mm^2~'/mg)'))+
  annotate("text", label = "r=0.06", x = 1.6, y =17,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

c2<-ggplot(data=as.data.frame(output),aes(x=cwm.height,y=cwm.sm))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "CWM vegetative height (m)", y ="CWM seed mass (g)")+
  annotate("text", label = "r=0.65",fontface="bold", x = 1.6, y =3.5,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

c3<-ggplot(data=as.data.frame(output),aes(x=cwm.height,y=cwm.fr))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "CWM vegetative height (m)", y ="CWM pollination mode")+
  annotate("text", label = "r=-0.40",fontface="bold", x = 1.6, y =.75,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

c4<-ggplot(data=as.data.frame(output),aes(x=cwm.sm,y=cwm.sla))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "CWM seed mass (m)", y =bquote('CWM SLA ('*mm^2~'/mg)'))+
  annotate("text", label = "r=0.14", x = 3, y =17,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

c5<-ggplot(data=as.data.frame(output),aes(x=cwm.fr,y=cwm.sla))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "CWM pollination mode", y =bquote('CWM SLA ('*mm^2~'/mg)'))+
  annotate("text", label = "r=0.41",fontface="bold", x = 0.5, y =17,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

c6<-ggplot(data=as.data.frame(output),aes(x=cwm.fr,y=cwm.sm))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "CWM pollination mode", y ="CWM seed mass (g)")+
  annotate("text", label = "r=-0.23",fontface="bold", x = 0.5, y =4,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

#make a pannel of graphs from ggplot objects
multiplot <- function(..., plotlist=NULL, cols) {
  require(grid)
  
  plots <- c(list(...), plotlist)
  numPlots = length(plots)
  plotCols = cols                         
  plotRows = ceiling(numPlots/plotCols) 
  
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(plotRows, plotCols)))
  vplayout <- function(x, y)
    viewport(layout.pos.row = x, layout.pos.col = y)
  
  for (i in 1:numPlots) {
    curRow = ceiling(i/plotCols)
    curCol = (i-1) %% plotCols + 1
    print(plots[[i]], vp = vplayout(curRow, curCol ))
  } 
}

#produce fig. 4
multiplot(c1,c2,c3,c4,c5,c6, cols=3) 

#trait correlations at the species level (fig. S7)
#add pollination mode factor for boxplots
trait_sp<-trait_data
trait_sp$flowers.char<-trait_sp$flowers
trait_sp$flowers.char[trait_sp$flowers.char==0]<-"No"
trait_sp$flowers.char[trait_sp$flowers.char==1]<-"Yes"

rcorr(as.matrix(trait_sp[1:4]))

#make plots
t1<-ggplot(data=trait_sp,aes(x=plant.height,y=SLA))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "Vegetative height (m)", y =bquote('SLA ('*mm^2~'/mg)'))+
  annotate("text", label = "r=-0.14", x = 1.6, y =24,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

t2<-ggplot(data=trait_sp,aes(x=plant.height,y=log(seed.mass)))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "Vegetative height (m)", y ="log seed mass (g)")+
  annotate("text", label = "r=-0.05", x = 1.6, y =3.5,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

t3<-ggplot(data=trait_sp,aes(x=flowers.char,y=plant.height))+
  geom_boxplot(color="black")+
  labs(x = "Pollination mode", y ="Vegetative height (m)")+
  annotate("text", label = "r=-0.16", x = 1.5, y =2,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

t4<-ggplot(data=trait_sp,aes(x=log(seed.mass),y=SLA))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "log seed mass (m)", y =bquote('SLA ('*mm^2~'/mg)'))+
  annotate("text", label = "r=-0.19", x = 3, y =24,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

t5<-ggplot(data=trait_sp,aes(x=flowers.char,y=SLA))+
  geom_boxplot(color="black")+
  labs(x = "Pollination mode", y =bquote('SLA ('*mm^2~mg^-1*')'))+
  annotate("text", label = "r=0.11", x = 1.5, y =24,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

t6<-ggplot(data=trait_sp,aes(x=flowers.char,y=log(seed.mass)))+
  geom_boxplot(color="black")+
  labs(x = "Pollination mode", y ="log seed mass (g)")+
  annotate("text", label = "r=0.15", x = 1.5, y =2.5,size=6)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

#make a pannel of graphs (fig. S7)
multiplot(t1,t2,t3,t4,t5,t6, cols=3)

##C4 abundance vs traits (Fig. S8)
c4.abun<-species_abund_ag[,colnames(species_abund_ag) %in% c("Andropogon.gerardii","Schizachyrium.scoparium","Sorghastrum.nutans","Panicum.virgatum")]
c4.abun$abun<-rowSums(c4.abun)
c4.abun$cwm.height<-site_data$cwm.height
c4.abun$cwm.fr<-site_data$cwm.fr

#linear models to caluculate p-values and R^2 for the following graphs
mod.c4_height<-lm(cwm.height~abun,data=c4.abun)
summary(mod.c4_height)

mod.c4_fr<-lm(cwm.fr~abun,data=c4.abun)
summary(mod.c4_fr)

a1<-ggplot(data=c4.abun,aes(x=abun,y=cwm.height))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "Sown C4 grass abundance (% cover)", y ="CWM vegetative height (m)")+
  annotate("text", label = "p<0.001~~R^{2}==0.40",parse = TRUE, x = 20, y =2,size=7)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

a2<-ggplot(data=c4.abun,aes(x=abun,y=cwm.fr))+
  geom_point(size=3.5,shape=16)+
  geom_smooth(method=lm,se=F,size=1,colour="black",fullrange=T)+
  labs(x = "Sown C4 grass abundance (% cover)", y ="CWM pollination mode")+
  annotate("text", label = "p<0.001~~R^{2}==0.52",parse = TRUE, x = 20, y =.75,size=7)+
  theme(axis.line.x = element_line(color = "black",size=1), axis.line.y = element_line(color = "black",size=1),
        text = element_text(size=20),axis.text=element_text(colour="black"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"))

#produce fig. S8
multiplot(a1,a2, cols=1)